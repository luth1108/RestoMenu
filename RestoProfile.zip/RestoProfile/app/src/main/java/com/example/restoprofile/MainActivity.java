package com.example.restoprofile;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView img_map,img_call,img_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        klikMap();
        klikTelepon();
        klikEmail();
    }

    private void klikMap(){
        img_map = findViewById(R.id.imgMap);
        img_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Koordinat tujuan (latitude dan longitude)
                double latitude = -6.982501;
                double longitude = 110.409206;

                // Buat Intent untuk membuka aplikasi peta
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/maps/@" + latitude + "," + longitude + ",15z"));
                startActivity(intent);
            }
        });
    }

    private void klikTelepon(){
        img_call = findViewById(R.id.imgCall);
        img_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "089510619396"; // Ganti dengan nomor telepon yang diinginkan
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + phoneNumber));
                startActivity(intent);
            }
        });
    }

    private void klikEmail(){
        img_email = findViewById(R.id.imgEmail);
        img_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = "111202113823@mhs.dinus.ac.id"; // Ganti dengan alamat email yang dituju
                String subject = "Tanya Seputar Resto"; // Subjek email
                String uriText = "mailto:" + email +
                        "?subject=" + Uri.encode(subject);
                Uri uri = Uri.parse(uriText);
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(uri);
                startActivity(intent);
            }
        });
    }
}